import os
import sys
import unittest
from unittest.mock import patch, Mock
from pathlib import Path
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from tushare_source import fetch, query, stock_code, get_token


class TushareTests(unittest.TestCase):
    def test_exchange_codes(self):
        self.assertEqual(stock_code('600519'),'600519.SH')
        self.assertEqual(stock_code('000001'),'000001.SZ')
        self.assertEqual(stock_code('920001'),'920001.BJ')
        with self.assertRaises(ValueError):
            stock_code('bad')

    @patch.dict(os.environ,{'TUSHARE_TOKEN':'PRIVATE_TEST_TOKEN'})
    def test_server_secret(self):
        self.assertEqual(get_token(),'PRIVATE_TEST_TOKEN')

    @patch('tushare_source.query')
    def test_adjusted_return(self,q):
        q.side_effect = [pd.DataFrame({'trade_date':['20240102','20240103','20240104'],
                                      'close':[100,50,55]}),
                         pd.DataFrame({'trade_date':['20240102','20240103','20240104'],
                                      'adj_factor':[1,2,2]})]
        s,source=fetch('股票','600519','2024-01-02','2024-01-04','PRIVATE_TEST_TOKEN')
        self.assertAlmostEqual(s.iloc[-1]/s.iloc[0]-1,.1)
        self.assertIn('adj_factor',source)
        self.assertEqual(q.call_count,2)

    @patch('tushare_source.query')
    def test_missing_factor_rejected(self,q):
        q.side_effect = [pd.DataFrame({'trade_date':['20240102','20240103'],'close':[100,50]}),
                         pd.DataFrame({'trade_date':['20240102'],'adj_factor':[1]})]
        with self.assertRaises(ValueError):
            fetch('股票','600519','2024-01-02','2024-01-04','PRIVATE_TEST_TOKEN')

    @patch('tushare_source.requests.post')
    def test_permission_error_does_not_echo_token(self,post):
        response=Mock()
        response.status_code=200
        response.json.return_value={'code':2002,'msg':'PRIVATE_TEST_TOKEN'}
        post.return_value=response
        with self.assertRaises(ValueError) as err:
            query('daily',{},'trade_date,close','PRIVATE_TEST_TOKEN')
        self.assertNotIn('PRIVATE_TEST_TOKEN',str(err.exception))
        self.assertTrue(post.call_args.args[0].startswith('https://'))
        self.assertFalse(post.call_args.kwargs['allow_redirects'])

    @patch('tushare_source.time.sleep')
    @patch('tushare_source.requests.post')
    def test_timeout_then_success(self,post,sleep):
        import requests
        response=Mock(status_code=200)
        response.json.return_value={'code':0,'data':{'fields':['trade_date','adj_factor'],'items':[['20240102',1.5]]}}
        post.side_effect=[requests.Timeout(),response]
        frame=query('adj_factor',{},'trade_date,adj_factor','PRIVATE_TEST_TOKEN')
        self.assertEqual(frame.iloc[0]['adj_factor'],1.5)
        self.assertEqual(post.call_count,2)
        self.assertEqual(sleep.call_count,1)

    @patch('tushare_source.time.sleep')
    @patch('tushare_source.requests.post')
    def test_retry_limit_and_message(self,post,sleep):
        import requests
        post.side_effect=requests.Timeout('PRIVATE_TEST_TOKEN')
        with self.assertRaises(ValueError) as err:
            query('adj_factor',{},'trade_date,adj_factor','PRIVATE_TEST_TOKEN')
        self.assertEqual(post.call_count,3)
        self.assertIn('请求超时',str(err.exception))
        self.assertNotIn('PRIVATE_TEST_TOKEN',str(err.exception))

    @patch('tushare_source.get_token',return_value='TEST')
    @patch('tushare_source.fetch')
    def test_fresh_cache_reuses_successful_series(self,fetch_mock,token):
        import tempfile
        from tushare_source import load
        dates=pd.date_range('2024-01-02',periods=3)
        def fake(kind,code,start,end,secret):
            return pd.Series([100.,101.,102.],index=dates,name=kind+':'+code),'测试来源'
        fetch_mock.side_effect=fake
        with tempfile.TemporaryDirectory() as tmp,patch.dict(os.environ,{'APP_DATA_DIR':tmp}):
            a=[dict(kind='股票',code='600519')]
            load(a,'2024-01-02','2024-01-04')
            self.assertEqual(fetch_mock.call_count,2)
            _,notes=load(a,'2024-01-02','2024-01-04')
            self.assertEqual(fetch_mock.call_count,2)
            self.assertTrue(any('复用15分钟' in note for note in notes))


if __name__=='__main__':
    unittest.main(verbosity=2)
