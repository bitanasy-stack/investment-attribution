"""验证复杂配置的模板切换、默认数据模式与元数据保存，不发起外部请求。"""
import os
import sys
import json
import tempfile
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from streamlit.testing.v1 import AppTest
import storage as db

with tempfile.TemporaryDirectory() as tmp:
    original=db.DB
    try:
        db.DB=Path(tmp)/'check.sqlite3'
        db.init()
        db.register('rich_test','Test2026!')
        uid=db.login('rich_test','Test2026!')
        with patch.dict(os.environ,{'TUSHARE_TOKEN':'TEST_ONLY_NO_NETWORK'}):
            at=AppTest.from_file(str(Path(__file__).resolve().parents[1]/'app.py'),default_timeout=30)
            at.session_state['uid']=uid
            at.session_state['username']='rich_test'
            at.run()
            assert not at.exception
            assert next(x for x in at.selectbox if x.label=='数据模式').value=='Tushare行情'
            assert len(at.dataframe[0].value)==10
            selector=next(x for x in at.selectbox if x.label=='配置模板')
            assert '科技主题组合 8项' in selector.options
            selector.select('科技主题组合 8项').run()
            assert not at.exception
            assert len(at.dataframe[0].value)==8
            assert '688981' in list(at.dataframe[0].value['代码'])
            next(x for x in at.selectbox if x.label=='配置模板').select('股票基金混合组合 8项').run()
            assert not at.exception
            assert len(at.dataframe[0].value)==8
            next(b for b in at.button if b.label=='保存组合配置').click().run()
            assert not at.exception
            saved=json.loads(db.portfolios(uid)[0]['config'])
            assert len(saved['assets'])==8
            assert saved['mode']=='Tushare行情'
            assert all('sector' in a and 'role' in a for a in saved['assets'])
            print('PASS: 10项默认配置、Tushare默认模式、8项模板切换、行业和配置角色保存。')
    finally:
        db.DB=original
