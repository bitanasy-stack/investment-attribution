import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from allocation import TEMPLATES, editor_frame, parse_frame, preview
from core import validate_assets


class AllocationTests(unittest.TestCase):
    def test_templates_are_valid_and_roundtrip(self):
        for items in TEMPLATES.values():
            validate_assets(items)
            self.assertEqual(parse_frame(editor_frame(items)),items)

    def test_amounts_and_unallocated(self):
        frame=editor_frame(TEMPLATES['多行业股票组合 10项'])
        rows,summary=preview(frame,200000)
        self.assertAlmostEqual(rows['配置金额 元'].sum(),200000)
        self.assertEqual(summary['unallocated'],0)
        self.assertEqual(summary['stock'],100)
        frame.loc[0,'比例 %']=2
        _,summary=preview(frame,200000)
        self.assertAlmostEqual(summary['unallocated'],20000)


if __name__=='__main__':
    unittest.main()
