"""用确定性的测试行情验证云端同款保存流程，不声称进行了真实行情调用。"""
import sys
import tempfile
import json
from pathlib import Path
import numpy as np
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from streamlit.testing.v1 import AppTest
import storage as db
from core import analyze
from allocation import TEMPLATES

with tempfile.TemporaryDirectory() as temp:
    old=db.DB
    try:
        db.DB=Path(temp)/'ui.sqlite3'
        db.init()
        db.register('history_test','History2026!')
        uid=db.login('history_test','History2026!')
        assets=TEMPLATES['多行业股票组合 10项']
        dates=pd.bdate_range('2025-10-27',periods=100)
        p=pd.DataFrame({a['kind']+':'+a['code']:100*(1+v*np.linspace(0,1,len(dates)))
                        for a,v in zip(assets,np.linspace(-.4,.5,10))},index=dates)
        p['基准:000300']=100
        cfg=dict(assets=assets,start=str(dates[0].date()),end=str(dates[-1].date()),
                 capital=100000,risk_free=.02,mode='Tushare行情')
        r=analyze(p,assets)
        db.save_portfolio(uid,'原组合',cfg)
        at=AppTest.from_file(str(Path(__file__).resolve().parents[1]/'app.py'),default_timeout=30)
        at.session_state['uid']=uid
        at.session_state['username']='history_test'
        at.session_state['last']=(r,cfg,'原组合',['仅测试用行情'])
        at.run()
        assert not at.exception
        next(b for b in at.button if b.label=='将两个历史对照保存到我的账户').click().run()
        assert not at.exception
        assert len(db.portfolios(uid))==3
        assert len(db.history(uid))==2
        next(b for b in at.button if b.label=='将两个历史对照保存到我的账户').click().run()
        assert len(db.portfolios(uid))==3
        at.radio[0].set_value('多组合对比').run()
        assert not at.exception
        assert len(at.multiselect[0].value)==3
        assert str(at.date_input[0].value)==r['start']
        assert next(x for x in at.selectbox if x.label=='统一数据模式').value=='Tushare行情'
        print('PASS: 两个历史对照、账户保存、同名不覆盖、历史记录、同区间三组合默认比较。')
    finally:
        db.DB=old
