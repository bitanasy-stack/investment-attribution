import sys
import unittest
from pathlib import Path
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from core import analyze
from contribution_view import breakdown, static_html


class ContributionTests(unittest.TestCase):
    def test_positive_negative_reconcile_and_units(self):
        assets=[dict(kind='股票',code='600519',name='正资产',weight=.2),
                dict(kind='股票',code='000001',name='负资产',weight=.5),
                dict(kind='基金',code='110011',name='平资产',weight=.3)]
        p=pd.DataFrame({'股票:600519':[100,105,110],'股票:000001':[100,95,80],
                        '基金:110011':[1,1,1],'基准:000300':[100,101,102]},index=pd.date_range('2024-01-01',periods=3))
        result=analyze(p,assets)
        c,t,s=breakdown(result,100000)
        self.assertAlmostEqual(s['positive'],.02)
        self.assertAlmostEqual(s['negative'],-.1)
        self.assertAlmostEqual(s['net'],-.08)
        self.assertAlmostEqual(s['profit'],-8000)
        self.assertEqual([s['positive_count'],s['negative_count'],s['flat_count']],[1,1,1])
        self.assertAlmostEqual(t.loc[t['代码']=='600519','贡献 百分点'].iloc[0],2)
        self.assertAlmostEqual(t['初始投入 元'].sum(),100000)
        report=static_html(result,dict(capital=100000,mode='Tushare行情'),'<script>bad</script>',['source & test'])
        self.assertIn('<svg',report)
        self.assertIn('负贡献',report)
        self.assertNotIn('<script>',report)
        self.assertIn('&lt;script&gt;',report)

    def test_zero_net_and_all_flat(self):
        a=[dict(kind='股票',code='600519',name='A',weight=1)]
        p=pd.DataFrame({'股票:600519':[100,100,100],'基准:000300':[100,100,100]},index=pd.date_range('2024-01-01',periods=3))
        _,_,s=breakdown(analyze(p,a),100000)
        self.assertEqual(s['flat_count'],1)
        self.assertEqual(s['net'],0)


if __name__=='__main__':
    unittest.main()
