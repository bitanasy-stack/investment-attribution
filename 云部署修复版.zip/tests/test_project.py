import sys
import tempfile
import unittest
from pathlib import Path
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from core import analyze, validate_assets
import storage as db


class CalculationTests(unittest.TestCase):
    def setUp(self):
        self.assets = [dict(kind='股票',code='600519',name='A',weight=.6),
                       dict(kind='基金',code='110011',name='B',weight=.4)]
        self.prices = pd.DataFrame({'股票:600519':[100,120,110], '基金:110011':[1,1,1.2],
                                    '基准:000300':[100,110,105]}, index=pd.date_range('2024-01-01', periods=3))

    def test_fixed_holdings_and_contribution(self):
        r = analyze(self.prices,self.assets)
        self.assertAlmostEqual(r['curve']['组合'].iloc[-1],114000)
        self.assertAlmostEqual(r['metrics']['累计收益率'],.14)
        self.assertAlmostEqual(r['contribution']['收益贡献'].sum(),.14)
        self.assertAlmostEqual(r['contribution']['盈亏金额'].sum(),14000)
        self.assertAlmostEqual(r['metrics']['超额收益率'],.09)

    def test_drawdown(self):
        p = self.prices.copy()
        p['股票:600519'] = [100,120,90]
        p['基金:110011'] = [1,1.2,.9]
        self.assertAlmostEqual(analyze(p,self.assets)['metrics']['最大回撤'],.25)

    def test_bad_weights_duplicates_and_nonfinite(self):
        for assets in [self.assets[:1], [self.assets[0],self.assets[0]],
                       [dict(kind='股票',code='600519',name='A',weight=np.nan)]]:
            with self.assertRaises(ValueError):
                validate_assets(assets)

    def test_common_dates_and_small_sample(self):
        p = self.prices.copy()
        p.iloc[1,0] = np.nan
        with self.assertRaises(ValueError):
            analyze(p,self.assets)

    def test_zero_vol_and_bad_capital(self):
        p = self.prices.copy()
        p[:] = 1
        self.assertTrue(np.isnan(analyze(p,self.assets)['metrics']['夏普比率']))
        with self.assertRaises(ValueError):
            analyze(p,self.assets,-1)


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old = db.DB
        db.DB = Path(self.tmp.name) / 'test.sqlite3'
        db.init()
        db.register('alice','Password123')
        db.register('bob','Password456')
        self.a = db.login('alice','Password123')
        self.b = db.login('bob','Password456')

    def tearDown(self):
        db.DB = self.old
        self.tmp.cleanup()

    def test_login_hash_and_duplicate(self):
        self.assertIsNotNone(self.a)
        self.assertIsNone(db.login('alice','wrong'))
        self.assertIsNone(db.login("' OR 1=1 --",'Password123'))
        with self.assertRaises(ValueError):
            db.register('alice','Password123')
        with db.connect() as c:
            row = c.execute('SELECT * FROM users WHERE id=?',(self.a,)).fetchone()
            self.assertNotEqual(row['password'],'Password123')

    def test_user_isolation_and_update(self):
        db.save_portfolio(self.a,'组合',{'a':1})
        self.assertEqual(db.portfolios(self.b),[])
        ident = db.portfolios(self.a)[0]['id']
        db.delete_portfolio(self.b,ident)
        self.assertEqual(len(db.portfolios(self.a)),1)
        db.save_portfolio(self.a,'组合',{'a':2})
        self.assertEqual(len(db.portfolios(self.a)),1)
        db.delete_portfolio(self.a,ident)
        self.assertEqual(db.portfolios(self.a),[])


if __name__ == '__main__':
    unittest.main(verbosity=2)
