"""Streamlit 真正运行脚本的集成测试，不依赖截图或外部行情。"""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from streamlit.testing.v1 import AppTest
import storage as db



def main():
    import tempfile
    original_db = db.DB
    with tempfile.TemporaryDirectory() as temp:
        db.DB = Path(temp) / "ui.sqlite3"
        try:
            db.init()
            try:
                db.register('ui_test', 'UITest2026!')
            except ValueError:
                pass
            at = AppTest.from_file(str(Path(__file__).resolve().parents[1] / 'app.py'), default_timeout=30).run()
            assert not at.exception
            at.text_input[0].set_value('ui_test')
            at.text_input[1].set_value('UITest2026!')
            at.button[0].click().run()
            assert not at.exception
            next(b for b in at.button if b.label == '创建三个示例组合').click().run()
            assert not at.exception
            at.selectbox[0].select('均衡组合').run()
            next(b for b in at.button if b.label == '开始分析并保存记录').click().run()
            assert not at.exception, at.exception
            assert len(at.metric) == 14
            at.radio[0].set_value('多组合对比').run()
            next(b for b in at.button if b.label == '比较组合').click().run()
            assert not at.exception
            assert len(at.dataframe) == 1
            at.radio[0].set_value('历史记录').run()
            assert not at.exception
            assert len(at.expander) >= 1
            at.radio[0].set_value('使用说明').run()
            assert not at.exception
            next(b for b in at.button if b.label == '退出登录').click().run()
            assert not at.exception
            assert len(at.metric) == 0
            print('PASS: 登录、示例组合、组合分析、7项指标、三组合对比、历史记录、使用说明、退出登录。')
        finally:
            db.DB = original_db


if __name__ == "__main__":
    main()
