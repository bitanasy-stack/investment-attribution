import sys
import unittest
from pathlib import Path
import numpy as np
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from allocation import TEMPLATES
from core import analyze, validate_assets
from historical_comparison import build_comparisons


class HistoricalTests(unittest.TestCase):
    def setUp(self):
        self.assets=TEMPLATES['多行业股票组合 10项']
        self.dates=pd.bdate_range('2025-10-27',periods=100)
        self.cfg=dict(assets=self.assets,start=str(self.dates[0].date()),end=str(self.dates[-1].date()),
                      capital=100000,risk_free=.02,mode='Tushare行情')

    def calculate(self,returns):
        p=pd.DataFrame({a['kind']+':'+a['code']:100*(1+ret*np.linspace(0,1,100))
                        for a,ret in zip(self.assets,returns)},index=self.dates)
        p['基准:000300']=100*(1+.03*np.linspace(0,1,100))
        return analyze(p,self.assets)

    def test_same_snapshot_weights_returns_and_metadata(self):
        r=self.calculate(np.linspace(-.4,.5,10))
        outputs,table=build_comparisons(r,self.cfg,'原组合')
        self.assertEqual(len(outputs),2)
        self.assertEqual(len(table),3)
        self.assertAlmostEqual(outputs[0]['result']['metrics']['累计收益率'],.405)
        self.assertAlmostEqual(outputs[1]['result']['metrics']['累计收益率'],.3)
        for o,size in zip(outputs,[3,5]):
            validate_assets(o['config']['assets'])
            self.assertEqual(len(o['config']['assets']),size)
            self.assertGreater(o['uplift'],0)
            self.assertEqual(o['result']['observations'],r['observations'])
            self.assertEqual(o['result']['start'],r['start'])
            self.assertEqual(o['result']['end'],r['end'])
            self.assertIn('事后',o['config']['construction']['method'])
            self.assertLessEqual(len(o['name']),60)
        self.assertAlmostEqual(self.assets[0]['weight'],.12)

    def test_all_negative_is_not_called_positive(self):
        r=self.calculate(np.linspace(-.5,-.05,10))
        outputs,_=build_comparisons(r,self.cfg,'原组合')
        self.assertTrue(all(o['result']['metrics']['累计收益率']<0 for o in outputs))
        self.assertTrue(all(o['uplift']>0 for o in outputs))

    def test_no_fake_improvement(self):
        r=self.calculate([.1]*10)
        with self.assertRaises(ValueError):
            build_comparisons(r,self.cfg,'原组合')

    def test_demo_and_missing_snapshot_rejected(self):
        r=self.calculate(np.linspace(-.4,.5,10))
        with self.assertRaises(ValueError):
            build_comparisons(r,dict(self.cfg,mode='离线演示'),'原组合')
        r.pop('prices')
        with self.assertRaises(ValueError):
            build_comparisons(r,self.cfg,'原组合')

    def test_inconsistent_result_rejected(self):
        r=self.calculate(np.linspace(-.4,.5,10))
        r['metrics']['累计收益率']=5
        with self.assertRaises(ValueError):
            build_comparisons(r,self.cfg,'原组合')


if __name__=='__main__':
    unittest.main(verbosity=2)
