"""重建合成教学数据。仅在主动运行时覆盖demo CSV，不是真实历史行情。"""
from pathlib import Path
import numpy as np
import pandas as pd

rng = np.random.default_rng(20241026)
dates = pd.bdate_range('2024-01-02', '2024-12-31')
market = rng.normal(.00035, .009, len(dates))
specs = [('股票:600519',1700,.0003,.010,.9), ('股票:000001',10,.0001,.008,.7),
         ('基金:110011',2.5,.00025,.005,.65), ('基金:161725',1.2,-.00015,.009,1.0),
         ('基准:000300',3500,0,.002,1.0)]
data = {}
for key, initial, mu, sigma, beta in specs:
    data[key] = initial * np.exp(np.cumsum(beta * market + mu + rng.normal(0, sigma, len(dates))))
out = Path(__file__).resolve().parents[1] / 'data' / 'demo_prices.csv'
pd.DataFrame(data,index=dates).to_csv(out,index_label='date')
print('已重建合成演示数据：', out)
